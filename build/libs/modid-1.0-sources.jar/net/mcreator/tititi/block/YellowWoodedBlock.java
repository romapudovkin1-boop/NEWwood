package net.mcreator.tititi.block;

import net.minecraft.class_2248;
import net.minecraft.class_2498;
import net.minecraft.class_4970;

public class YellowWoodedBlock extends class_2248 {
	public YellowWoodedBlock(class_4970.class_2251 properties) {
		super(properties.method_9626(class_2498.field_11547).method_9629(1.7f, 10f).method_51371());
	}
}