/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.tititi.init;

import net.minecraft.class_1959;
import net.minecraft.class_2246;
import net.minecraft.class_2378;
import net.minecraft.class_2680;
import net.minecraft.class_2794;
import net.minecraft.class_2874;
import net.minecraft.class_2960;
import net.minecraft.class_3754;
import net.minecraft.class_4766;
import net.minecraft.class_5321;
import net.minecraft.class_5363;
import net.minecraft.class_5932;
import net.minecraft.class_6544;
import net.minecraft.class_6686;
import net.minecraft.class_6880;
import net.minecraft.class_7134;
import net.minecraft.class_7510;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;
import java.util.List;
import java.util.ArrayList;

import com.mojang.datafixers.util.Pair;

import com.google.common.base.Suppliers;

public class TiModBiomes {
	public static void load(MinecraftServer server) {
		class_2378<class_5363> levelStemTypeRegistry = server.method_30611().method_30530(class_7924.field_41224);
		class_2378<class_1959> biomeRegistry = server.method_30611().method_30530(class_7924.field_41236);
		for (class_5363 levelStem : levelStemTypeRegistry.method_10220().toList()) {
			class_6880<class_2874> dimensionType = levelStem.comp_1012();
			if (dimensionType.method_40225(class_7134.field_37666)) {
				class_2794 chunkGenerator = levelStem.comp_1013();
				// Inject biomes to biome source
				if (chunkGenerator.method_12098() instanceof class_4766 noiseSource) {
					List<Pair<class_6544.class_4762, class_6880<class_1959>>> parameters = new ArrayList<>(noiseSource.method_49506().method_38128());
					addParameterPoint(parameters, new Pair<>(new class_6544.class_4762(class_6544.class_6546.method_38121(-0.5f, 0.5f), class_6544.class_6546.method_38121(-0.5f, 0.5f), class_6544.class_6546.method_38121(0.3f, 1f), class_6544.class_6546.method_38121(-0.5f, 0.5f),
							class_6544.class_6546.method_38120(0.0f), class_6544.class_6546.method_38121(-1f, 1f), 0), biomeRegistry.method_46747(class_5321.method_29179(class_7924.field_41236, class_2960.method_60655("ti", "yellow_wood")))));
					addParameterPoint(parameters, new Pair<>(new class_6544.class_4762(class_6544.class_6546.method_38121(-0.5f, 0.5f), class_6544.class_6546.method_38121(-0.5f, 0.5f), class_6544.class_6546.method_38121(0.3f, 1f), class_6544.class_6546.method_38121(-0.5f, 0.5f),
							class_6544.class_6546.method_38120(1.0f), class_6544.class_6546.method_38121(-1f, 1f), 0), biomeRegistry.method_46747(class_5321.method_29179(class_7924.field_41236, class_2960.method_60655("ti", "yellow_wood")))));
					chunkGenerator.field_12761 = class_4766.method_49501(new class_6544.class_6547<>(parameters));
					chunkGenerator.field_39412 = Suppliers
							.memoize(() -> class_7510.method_44210(List.copyOf(chunkGenerator.field_12761.method_28443()), biome -> chunkGenerator.field_39413.apply(biome).method_30983(), true));
				}
				if (chunkGenerator instanceof class_3754 noiseGenerator) {
					((TiModNoiseGeneratorSettings) (Object) noiseGenerator.field_24774.comp_349()).settiDimensionTypeReference(dimensionType);
				}
			}
		}
	}

	public static class_6686.class_6708 adaptSurfaceRule(class_6686.class_6708 currentRuleSource, class_6880<class_2874> dimensionType) {
		if (dimensionType.method_40225(class_7134.field_37666))
			return injectOverworldSurfaceRules(currentRuleSource);
		return currentRuleSource;
	}

	private static class_6686.class_6708 injectOverworldSurfaceRules(class_6686.class_6708 currentRuleSource) {
		List<class_6686.class_6708> customSurfaceRules = new ArrayList<>();
		customSurfaceRules.add(
				preliminarySurfaceRule(class_5321.method_29179(class_7924.field_41236, class_2960.method_60655("ti", "yellow_wood")), class_2246.field_10219.method_9564(), class_2246.field_10566.method_9564(), class_2246.field_10255.method_9564()));
		if (currentRuleSource instanceof class_6686.class_6710 sequenceRuleSource) {
			customSurfaceRules.addAll(sequenceRuleSource.comp_209());
			return class_6686.method_39050(customSurfaceRules.toArray(class_6686.class_6708[]::new));
		} else {
			customSurfaceRules.add(currentRuleSource);
			return class_6686.method_39050(customSurfaceRules.toArray(class_6686.class_6708[]::new));
		}
	}

	private static class_6686.class_6708 preliminarySurfaceRule(class_5321<class_1959> biomeKey, class_2680 groundBlock, class_2680 undergroundBlock, class_2680 underwaterBlock) {
		return class_6686.method_39049(class_6686.method_39055(biomeKey),
				class_6686.method_39049(class_6686.method_39473(),
						class_6686.method_39050(
								class_6686.method_39049(class_6686.method_40023(0, false, 0, class_5932.field_29314),
										class_6686.method_39050(class_6686.method_39049(class_6686.method_39046(-1, 0), class_6686.method_39047(groundBlock)), class_6686.method_39047(underwaterBlock))),
								class_6686.method_39049(class_6686.method_40023(0, true, 0, class_5932.field_29314), class_6686.method_39047(undergroundBlock)))));
	}

	private static void addParameterPoint(List<Pair<class_6544.class_4762, class_6880<class_1959>>> parameters, Pair<class_6544.class_4762, class_6880<class_1959>> point) {
		if (!parameters.contains(point))
			parameters.add(point);
	}

	public interface TiModNoiseGeneratorSettings {
		void settiDimensionTypeReference(class_6880<class_2874> dimensionType);
	}
}