/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.tititi.init;

import net.mcreator.tititi.block.YellowWoodedBlock;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.mcreator.tititi.TiMod;

import java.util.function.Function;

public class TiModBlocks {
	public static class_2248 YELLOW_WOODED;

	public static void load() {
		YELLOW_WOODED = register("yellow_wooded", YellowWoodedBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends class_2248> B register(String name, Function<class_4970.class_2251, B> supplier) {
		return (B) class_2246.method_63053(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(TiMod.MODID, name)), (Function<class_4970.class_2251, class_2248>) supplier, class_4970.class_2251.method_9637());
	}
}