/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.tititi.init;

import net.mcreator.tititi.TiMod;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import java.util.function.Function;

public class TiModItems {
	public static class_1792 YELLOW_WOODED;

	public static void load() {
		YELLOW_WOODED = block(TiModBlocks.YELLOW_WOODED, "yellow_wooded");
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends class_1792> I register(String name, Function<class_1792.class_1793, ? extends I> supplier) {
		return (I) class_1802.method_63747(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(TiMod.MODID, name)), (Function<class_1792.class_1793, class_1792>) supplier);
	}

	private static class_1792 block(class_2248 block, String name) {
		return block(block, name, new class_1792.class_1793());
	}

	private static class_1792 block(class_2248 block, String name, class_1792.class_1793 properties) {
		return class_1802.method_51348(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(TiMod.MODID, name)), prop -> new class_1747(block, prop), properties);
	}
}