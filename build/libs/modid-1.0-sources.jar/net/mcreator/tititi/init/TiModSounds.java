/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.tititi.init;

import net.mcreator.tititi.TiMod;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7923;

public class TiModSounds {
	public static class_3414 BREAKNEW;

	public static void load() {
		BREAKNEW = register("breaknew", class_3414.method_47908(class_2960.method_60655("ti", "breaknew")));
	}

	private static class_3414 register(String registryname, class_3414 element) {
		return class_2378.method_10230(class_7923.field_41172, class_2960.method_60655(TiMod.MODID, registryname), element);
	}
}