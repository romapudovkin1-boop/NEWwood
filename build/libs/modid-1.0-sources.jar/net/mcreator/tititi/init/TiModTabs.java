/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.tititi.init;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_7706;

public class TiModTabs {
	public static void load() {
		ItemGroupEvents.modifyEntriesEvent(class_7706.field_40743).register(tabData -> {
			tabData.method_45421(TiModBlocks.YELLOW_WOODED.method_8389());
		});
	}
}