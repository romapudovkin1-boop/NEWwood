package net.mcreator.tititi.mixin;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Mixin;
import net.mcreator.tititi.event.ItemEvents;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1752;
import net.minecraft.class_1838;
import net.minecraft.class_3218;

@Mixin(class_1752.class)
public abstract class BoneMealItemMixin {
	@Inject(method = "useOn(Lnet/minecraft/world/item/context/UseOnContext;)Lnet/minecraft/world/InteractionResult;", at = @At("HEAD"), cancellable = true)
	public void useOn(class_1838 context, CallbackInfoReturnable<class_1269> cir) {
		if (context.method_8045() instanceof class_3218) {
			boolean result = ItemEvents.BONEMEAL_USED.invoker().onBonemealUsed(context.method_8037(), (class_1297) context.method_8036(), context.method_8041(), context.method_8045().method_8320(context.method_8037()));
			if (!result)
				cir.setReturnValue(class_1269.field_5814);
		}
	}
}