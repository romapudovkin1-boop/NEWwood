package net.mcreator.tititi.mixin;

import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.Mixin;
import net.mcreator.tititi.init.TiModBiomes;
import net.minecraft.class_2874;
import net.minecraft.class_5284;
import net.minecraft.class_6686;
import net.minecraft.class_6880;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;

@Mixin(class_5284.class)
public class NoiseGeneratorSettingsMixin implements TiModBiomes.TiModNoiseGeneratorSettings {
	@Unique
	private class_6880<class_2874> ti_dimensionTypeReference;

	@WrapMethod(method = "surfaceRule")
	public class_6686.class_6708 surfaceRule(Operation<class_6686.class_6708> original) {
		class_6686.class_6708 retval = original.call();
		if (this.ti_dimensionTypeReference != null) {
			retval = TiModBiomes.adaptSurfaceRule(retval, this.ti_dimensionTypeReference);
		}
		return retval;
	}

	@Override
	public void settiDimensionTypeReference(class_6880<class_2874> dimensionType) {
		this.ti_dimensionTypeReference = dimensionType;
	}
}