package net.mcreator.tititi.mixin;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Mixin;
import net.mcreator.tititi.event.PlayerEvents;
import net.minecraft.class_1657;

@Mixin(class_1657.class)
public abstract class PlayerMixin {
	@Inject(method = "tick()V", at = @At("TAIL"))
	public void tick(CallbackInfo ci) {
		PlayerEvents.END_PLAYER_TICK.invoker().onEndTick((class_1657) (Object) this);
	}

	@Inject(method = "giveExperiencePoints(I)V", at = @At("HEAD"))
	public void giveExperiencePoints(int amount, CallbackInfo ci) {
		PlayerEvents.XP_CHANGE.invoker().onXpChange((class_1657) (Object) this, amount);
	}

	@Inject(method = "giveExperienceLevels(I)V", at = @At("HEAD"))
	public void giveExperienceLevels(int amount, CallbackInfo ci) {
		PlayerEvents.LEVEL_CHANGE.invoker().onLevelChange((class_1657) (Object) this, amount);
	}
}